<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard</title>
    <link rel="stylesheet" type="text/css" href="Sstyle.css">

</head>
<body>

<!--  --------- navbar part -------- -->
<nav class="navbar">
    <div class="navbar-logo-left">
        <img src="../img/uiu_logo.png" alt="UIU Logo">
    </div>
    <div class="navbar-logo-right" id="profile-trigger">
        <img src="../img/user.png" alt="User">
    </div>
    <div class="profile-container text-center" id="profile-container">
        <div class="profile">
            <h4 class="mb-3">John Doe</h4>
            <div class="profile-info">
                <img src="../img/student.png" alt="Profile Picture" class="mb-3" style="width: 100px; height: 100px; border-radius: 50%;">
                <p class="mb-3">john.doe@example.com</p>
                <a href="#" class="btn btn-primary btn-sm mb-2">Change Password</a>
                <br>
                <a href="#" class="btn btn-danger btn-sm">Log Out</a>
            </div>
        </div>
    </div>
</nav>
<!-- ------------- banner part ----------- -->
<div class="banner-container">
    <div class="banner-text">
        <h1>Welcome to Your Student Dashboard</h1>
        <p>Explore your courses, assignments, grades, and more!</p>
    </div>
    <img src="../img/st_banner.jpg" alt="Banner" class="banner">
</div>

<!-- -------------features part in cards ----------- -->
<div class="card-section">
    <div class="card">
        <a href="">
            <img src="../img/st_banner.jpg" alt="Option 1">
            <div class="card-content">
            <h3>Teacher Availability</h3>
            <p>Click to view which faculties are available now</p>
        </div>
        </a>
    </div>
    <div class="card">
        <a href="">
        <img src="../img/st_banner.jpg" alt="Option 2">
        <div class="card-content">
            <h3>View Clubs</h3>
            <p>Join clubs and see upcoming club events</p>
        </div>
        </a>
        
    </div>
    <div class="card">
        <a href="">
        <img src="../img/st_banner.jpg" alt="Option 3">
        <div class="card-content">
        <h3>Shuttle Service</h3>
        <p>See availability of buses and time table</p>
        </div>
        </a>
        
    </div>
    <div class="card">
        <a href="">
        <img src="../img/st_banner.jpg" alt="Option 4">
        <div class="card-content">
            <h3>Canteen</h3>
            <p>See what's available at canteen</p>
        </div>
        </a>
        
    </div>
    <div class="card">
        <a href="">
        <img src="../img/st_banner.jpg" alt="Option 5">
        <div class="card-content">
            <h3>Gymnasium</h3>
            <p>Join gym or view the schedule</p>
        </div>
        </a>
        
    </div>
    <div class="card">
        <a href="../marketplace/marketplace.php">
        <img src="../img/st_banner.jpg" alt="Option 6">
        <div class="card-content">
            <h3>Marketplace</h3>
            <p>Buy or Sell items in campus</p>
        </div>
        </a>
    </div>
</div>

<!-- ------------ features end --------------- -->

<script>
    document.getElementById("profile-trigger").addEventListener("click", function() {
        var profileContainer = document.getElementById("profile-container");
        profileContainer.style.display = (profileContainer.style.display === "block") ? "none" : "block";
    });
</script>

</body>
</html>
