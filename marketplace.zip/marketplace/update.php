<?php
$conn = mysqli_connect("localhost", "root", '', "academia_connect");


$id = $_GET['updateid'];

$sql = "Select * from `ad` where ad_id=$id";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);

$title = $row['title'];
$description = $row['description'];
$price=$row['price'];

if (isset($_POST['submit'])) {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $price=$_POST['price'];


    $errors = array();

    if (empty($title)) {
        array_push($errors, "Title is required");
    }
    if (empty($price)) {
        array_push($errors, "Price is required");
    }
    if (count($errors) > 0) {
        foreach ($errors as $error) {
            echo "<div class='alert alert-danger'>$error</div>";
        }
    } else {



        $sql = "update `ad` set ad_id=$id, title='$title', description='$description', price='$price', post_time=NOW()
    where ad_id=$id";
        $result = mysqli_query($conn, $sql);

        if ($result) {
            header('location:my_ad.php');
        } else {
            die(mysqli_error($conn));
        }
    }

}


?>


<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css">

    <title>Update Task</title>
</head>

<body>
    <div class="container my-5">
        <form method="post">
            <div class="form-group">
                <label>Title</label>
                <input type="text" class="form-control" placeholder="Title" name="title" value=<?php
                echo "'$title'"; ?>>
            </div>
            <div class="form-group">
                <label>Description</label>
                <input type="text" class="form-control" placeholder="Description" name="description" value=<?php
                echo "'$description'"; ?>>
            </div>
            <div class="form-group">
                <label>Price</label>
                <input type="text" class="form-control" placeholder="Price" name="price" value=<?php
                echo "'$price'"; ?>>
            </div>


            <button type="submit" class="btn
            btn-primary" name="submit">Update</button>
        </form>
    </div>

</body>

</html>