<?php
$conn = mysqli_connect("localhost", "root", '', "academia_connect");
?>
<!-- 
INSERT INTO ad (student_id, title, description, price, post_time)
    VALUES ('$studentId', '$title', '$description', '$price', NOW())"; -->

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Task Master</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css">
</head>

<body>

  <div class="container">
    <br> <br>
    <h1>My Adds</h1>
    <!-- <button class="btn btn-primary my-5"><a href="task.php" class="text-light">Add task</a>
    </button>

    <button class="btn btn-primary my-5"><a href="complete.php" class="text-light">Completed task</a>
    </button> -->

    <table class="table">
      <thead>
        <tr>
          <th scope="col">Title</th>
          <th scope="col">Description</th>
          <th scope="col">Price</th>
          <th scope="col">Post Time</th>
          <th scope="col">Operations</th>
        </tr>
      </thead>

      <tbody>

        <?php
        session_start();
        $username = $_SESSION['username'];
        $sql = "Select * from `ad` where username = '$username'";
        $result = mysqli_query($conn, $sql);
        if ($result) {
          while ($row = mysqli_fetch_assoc($result)) {
            $ad_id = $row['ad_id'];
            $title = $row['title'];
            $description = $row['description'];
            $price=$row['price'];
            $post_time=$row['post_time'];

            echo '<tr>
            <td>' . $title . '</td>
            <td>' . $description . '</td>
            <td>' . $price . '</td>
            <td>' . $post_time . '</td>

            <td>

    <button class="btn btn-primary"><a href="update.php?
    updateid=' . $ad_id . '" class="text-light">Update</a></button>
    <button class="btn btn-danger"><a href="delete.php?
    deleteid=' . $ad_id . '" class="text-light">Delete</a></button>
    </td>
          </tr>';

          }
        }
        ?>


      </tbody>
    </table>
    <br>
    <br>
    <!-- <a href="logout.php" class="btn btn-warning">Logout</a> -->

  </div>

</body>

</html>