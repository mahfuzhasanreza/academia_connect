<?php
$conn = mysqli_connect("localhost", "root", '', "academia_connect");

if (isset($_GET['deleteid'])) {
    $id = $_GET['deleteid'];

    $sql1 = "DELETE FROM `availability` WHERE ad_id = $id";
    $result1 = mysqli_query($conn, $sql1);

    $sql3="DELETE FROM `buy_sell` WHERE ad_id = $id";
    $result3 = mysqli_query($conn, $sql3);
    
    $sql4="DELETE FROM `category` WHERE ad_id = $id";
    $result4 = mysqli_query($conn, $sql4);
    

    if ($result1 && $result3 && $result4) {
        $sql2 = "DELETE FROM `ad` WHERE ad_id = $id";
        $result2 = mysqli_query($conn, $sql2);

        if ($result2) {
            header('Location: my_ad.php');
        } else {
            die(mysqli_error($conn));
        }
    } else {
        die(mysqli_error($conn));
    }
  
}
?>
