# academia_connect

- Step-1: Open htdocs folder
- Step-2: Open in Terminal
- Step-3: Copy and Paste this line in Terminal
```c
git clone https://github.com/mahfuzhasanreza/academia_connect.git
```
- Step-4: Open `academia_connect` in VS Code and work on it
