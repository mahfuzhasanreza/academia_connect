<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Marketplace</title>
<style>

    body {
      margin: 0;
      padding: 0;
      font-family: Arial, sans-serif;
    }
/* ---- navbar css start ------ */

/* Existing navbar styles */
.navbar {
    background-color: #333;
    overflow: hidden;
    padding: 10px 20px;
    position: relative; 
}

.navbar-logo {
    float: left;
}

.navbar-logo img {
    height: 30px;
}


.navbar-options {
    position: absolute;
    top: 50%;
    right: 20px;
    transform: translateY(-50%);
    list-style: none;
    padding: 0;
    margin: 0;
}

.navbar-option {
    color: #fff;
    text-decoration: none;
    padding: 8px 15px;
}

.navbar-option:hover {
    background-color: #555; 
    transition: background-color 0.4s ease;
}


/* ---------navbar css ends------ */
        .banner {
            position: relative;
            height: 300px;
            background: url('../img/market.jpg') center/cover;
        }

        .overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5));
            color: #fff;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
            padding: 20px;
            box-sizing: border-box;
        }

/* ------------ ads part css start ------- */
.products {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-around;
    padding: 10px;
}

.product {
    width: calc(29% - 20px);
    margin: 7px;
    padding: 8px;
    background-color: #f9f9f9;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.product img {
    width: 100%;
    height: auto;
    border-radius: 8px;
}

.product-info {
    padding: 10px;
    position: relative;
}

.show-contact {
    display: block;
    text-align: center;
    margin-top: 10px;
    color: #333;
    cursor: pointer;
}

.contact-info {
    display: none;
    padding: 10px;
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    position: absolute;
    top: calc(100% + 10px); 
    left: 0;
    z-index: 1; 
}

/* --------- ads part css ends------- */

/* --------- filter-product ------- */
.filter-section {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 20px;
    background-color: #f9f9f9;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.filter-options {
    display: flex;
    align-items: center;
}

.filter-options label {
    margin-right: 10px;
}

.filter-options select {
    padding: 8px;
    border-radius: 4px;
    border: 1px solid #ccc;
}

.search-box {
    display: flex;
    align-items: center;
}

.search-box input[type="text"] {
    padding: 8px;
    border-radius: 4px;
    border: 1px solid #ccc;
}

.search-box button {
    padding: 8px 12px;
    border-radius: 4px;
    border: none;
    background-color: #333;
    color: #fff;
    cursor: pointer;
}

.search-box button:hover {
    background-color: #555;
}

/* --- adv filtering css--- */

.advanced-filter-form {
    margin-top: 20px;
    padding: 20px;
    background-color: #f9f9f9;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.advanced-filter-form form {
    display: flex;
    flex-direction: column;
}

.advanced-filter-form form label {
    margin-bottom: 5px;
}

.advanced-filter-form form input,
.advanced-filter-form form select {
    margin-bottom: 10px;
    padding: 8px;
    border-radius: 4px;
    border: 1px solid #ccc;
}

.advanced-filter-form form button {
    padding: 10px 20px;
    border-radius: 4px;
    border: none;
    background-color: #333;
    color: #fff;
    cursor: pointer;
}

.advanced-filter-form form button:hover {
    background-color: #555;
}



/* ---------filter part ends ------- */

</style>

</head>
<body>
<!-- ----------- navbar part starts -------- -->
<div class="navbar">
    <div class="navbar-logo">
        <img src="../img/uiu_logo.png" alt="Logo">
    </div>
    <div class="navbar-options" id="navbarOptions">
        <a href="#" class="navbar-option">Home</a>
        <a href="post_ad.php" class="navbar-option">Post Ad</a>
        <a href="#" class="navbar-option">My Ads</a>
    </div>
</div>


<!-- ------ navbar part ends here ---------- -->

<div class="banner">
    <div class="overlay">
        <h1>Welcome to Our Marketplace</h1>
        <p>Find amazing deals on a variety of products!</p>
    </div>
</div>
<!-- ---------- banner part ends --------- -->
<section>
  <!-- ----- filtering ----- -->
<div class="filter-section">
    <div class="filter-options">
        <label for="sort-by">Sort by:</label>
        <select id="sort-by">
            <option value="date-asc">Date (Ascending)</option>
            <option value="date-desc">Date (Descending)</option>
            <option value="price-asc">Price (Low to High)</option>
            <option value="price-desc">Price (High to Low)</option>
        </select>
    </div>
    <button id="advanced-filter-btn">Advanced Filtering</button>
    <div class="search-box">
        <input type="text" id="search" placeholder="Search...">
        <button id="search-btn">Search</button>
    </div>
</div>

<div class="advanced-filter-form" id="advanced-filter-form" style="display: none;">
    <form>
        <label for="price-range">Price Range:</label>
        <input type="number" id="price-range-min" placeholder="Min">
        <span>-</span>
        <input type="number" id="price-range-max" placeholder="Max">
        <br>
        <label for="product-name">Product Name:</label>
        <input type="text" id="product-name" placeholder="Enter product name">
        <br>
        <label for="trimester-no">Trimester No:</label>
        <input type="number" id="trimester-no" placeholder="Enter trimester number">
        <br>
        <label for="category">Category:</label>
        <select id="category">
            <option value="electronics">Electronics</option>
            <option value="book">Book</option>
        </select>
        <br>
        <label for="buy-sell">Buy/Sell:</label>
        <select id="buy-sell">
            <option value="buy">Buy</option>
            <option value="sell">Sell</option>
        </select>
        <br>
        <label for="availability">Availability:</label>
        <select id="availability">
            <option value="available">Available</option>
            <option value="not-available">Not Available</option>
        </select>
        <br>
        <button type="submit">Apply Filters</button>
    </form>
</div>


<!-- -------filtering ends here -------- -->

<!-- ------products part ----- -->
<div class="products">
    <div class="product">
        <img src="../img/product-1.jpg" alt="Product 1">
        <div class="product-info">
            <h3>Product 1</h3>
            <p>$50</p>
            <div class="show-contact" onclick="showContact(this)">Contact Seller</div> <!-- Contact Seller button -->
            <div class="contact-info"> <!-- Contact info -->
                <h3>Contact Information</h3>
                <p>Email: seller1@example.com</p>
                <p>Phone: +1234567890</p>
            </div>
        </div>
    </div>
    <div class="product">
        <img src="../img/product-2.jpg" alt="Product 1">
        <div class="product-info">
            <h3>Product 2</h3>
            <p>$50</p>
            <div class="show-contact" onclick="showContact(this)">Contact Seller</div> <!-- Contact Seller button -->
            <div class="contact-info"> <!-- Contact info -->
                <h3>Contact Information</h3>
                <p>Email: seller1@example.com</p>
                <p>Phone: +1234567890</p>
            </div>
        </div>
    </div>
    <div class="product">
        <img src="../img/product-3.jpg" alt="Product 1">
        <div class="product-info">
            <h3>Product 3</h3>
            <p>$50</p>
            <div class="show-contact" onclick="showContact(this)">Contact Seller</div> <!-- Contact Seller button -->
            <div class="contact-info"> <!-- Contact info -->
                <h3>Contact Information</h3>
                <p>Email: seller1@example.com</p>
                <p>Phone: +1234567890</p>
            </div>
        </div>
    </div>
    <div class="product">
        <img src="../img/product-4.jpg" alt="Product 1">
        <div class="product-info">
            <h3>Product 4</h3>
            <p>$50</p>
            <div class="show-contact" onclick="showContact(this)">Contact Seller</div> <!-- Contact Seller button -->
            <div class="contact-info"> <!-- Contact info -->
                <h3>Contact Information</h3>
                <p>Email: seller1@example.com</p>
                <p>Phone: +1234567890</p>
            </div>
        </div>
    </div>
    <!-- Add more products with similar structure -->
</div>

</section>

<script>
    function toggleNavbarOptions() {
    var navbarOptions = document.getElementById("navbarOptions");
    navbarOptions.style.display = navbarOptions.style.display === "block" ? "none" : "block";
    }

    function showContact(button) {
        var productInfo = button.parentElement; // Get the parent element of the button (product-info)
        var contactInfo = productInfo.querySelector('.contact-info'); // Find the contact info within the product-info

        if (contactInfo.style.display === 'block') {
            contactInfo.style.display = 'none';
        } else {
            // Set position of contact-info relative to product-info
            contactInfo.style.position = 'absolute';
            contactInfo.style.top = '0';
            contactInfo.style.left = '100%';
            contactInfo.style.display = 'block';
        }
    }

    document.addEventListener('DOMContentLoaded', function() {
        document.getElementById('advanced-filter-btn').addEventListener('click', function() {
            var form = document.getElementById('advanced-filter-form');
            if (form.style.display === 'none') {
                form.style.display = 'block';
            } else {
                form.style.display = 'none';
            }
        });
    });
</script>


</body>
</html>
