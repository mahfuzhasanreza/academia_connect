<h1>Welcome GYM MANAGER</h1>

<br>
<br>
<a href="logout.php" class="btn btn-warning">Logout</a>