<?php

    $con = mysqli_connect("localhost","root",'',"st_marketplace");

    if(!$con)
    {
        die("connection problem bitch");
    }

    $query = "select title, description, price from ad";
    $result = mysqli_query($con,$query);

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Marketplace</title>
    <link rel="stylesheet" type="text/css" href="Mstyle.css">
</head>
<body>

<!-- ----------- navbar part starts -------- -->
<div class="navbar">
    <div class="navbar-logo">
        <img src="../img/uiu_logo.png" alt="Logo">
    </div>
    <div class="navbar-options" id="navbarOptions">
        <a href="#" class="navbar-option">Home</a>
        <a href="post_ad.php" class="navbar-option">Post Ad</a>
        <a href="#" class="navbar-option">My Ads</a>
    </div>
</div>


<!-- ------ banner part starts here ---------- -->

<div class="banner">
    <div class="overlay">
        <h1>Welcome to Our Marketplace</h1>
        <p>Find amazing deals on a variety of products!</p>
    </div>
</div>
<!-- ---------- banner part ends --------- -->
<section>
  <!-- ----- filtering ----- -->

<div class="filter-section">
    <div class="filter-options">
        <label for="sort-by">Sort by:</label>
        <select id="sort-by">
            <option value="date-asc">Date (Ascending)</option>
            <option value="date-desc">Date (Descending)</option>
            <option value="price-asc">Price (Low to High)</option>
            <option value="price-desc">Price (High to Low)</option>
        </select>
    </div>
    <button id="advanced-filter-btn">Advanced Filtering</button>
    <div class="search-box">
        <input type="text" id="search" placeholder="Search...">
        <button id="search-btn">Search</button>
    </div>
</div>

<div class="advanced-filter-form" id="advanced-filter-form" style="display: none;">
    <form>
        <label for="price-range">Price Range:</label>
        <input type="number" id="price-range-min" placeholder="Min">
        <span>-</span>
        <input type="number" id="price-range-max" placeholder="Max">
        <br>
        <label for="product-name">Product Name:</label>
        <input type="text" id="product-name" placeholder="Enter product name">
        <br>
        <label for="trimester-no">Trimester No:</label>
        <input type="number" id="trimester-no" placeholder="Enter trimester number">
        <br>
        <label for="category">Category:</label>
        <select id="category">
            <option value="electronics">Electronics</option>
            <option value="book">Book</option>
        </select>
        <br>
        <label for="buy-sell">Buy/Sell:</label>
        <select id="buy-sell">
            <option value="buy">Buy</option>
            <option value="sell">Sell</option>
        </select>
        <br>
        <label for="availability">Availability:</label>
        <select id="availability">
            <option value="available">Available</option>
            <option value="not-available">Not Available</option>
        </select>
        <br>
        <button type="submit">Apply Filters</button>
    </form>
</div>

<!-- -------filtering ends here -------- -->

<!-- ------products part ----- -->
<div class="products">
    <div class="product">
        <img src="../img/product-1.jpg" alt="Product 1">
        <div class="product-info">
            <h3>Product 1</h3>
            <p>Little bit of description</p>
            <p>$50</p>
            <div class="show-contact" onclick="showContact(this)">Contact Seller</div> <!-- Contact Seller button -->
            <div class="contact-info"> <!-- Contact info -->
                <h3>Contact Information</h3>
                <p>Email: seller1@example.com</p>
                <p>Phone: +1234567890</p>
            </div>
        </div>
    </div>
    <div class="product">
        <img src="../img/product-2.jpg" alt="Product 1">
        <div class="product-info">
            <h3>Product 2</h3>
            <p>Little bit of description</p>
            <p>$50</p>
            <div class="show-contact" onclick="showContact(this)">Contact Seller</div> <!-- Contact Seller button -->
            <div class="contact-info"> <!-- Contact info -->
                <h3>Contact Information</h3>
                <p>Email: seller1@example.com</p>
                <p>Phone: +1234567890</p>
            </div>
        </div>
    </div>
    <div class="product">
        <img src="../img/product-3.jpg" alt="Product 1">
        <div class="product-info">
            <h3>Product 3</h3>
            <p>Little bit of description</p>
            <p>$50</p>
            <div class="show-contact" onclick="showContact(this)">Contact Seller</div> <!-- Contact Seller button -->
            <div class="contact-info"> <!-- Contact info -->
                <h3>Contact Information</h3>
                <p>Email: seller1@example.com</p>
                <p>Phone: +1234567890</p>
            </div>
        </div>
    </div>
    <div class="product">
        <img src="../img/product-4.jpg" alt="Product 1">
        <div class="product-info">
            <h3>Product 4</h3>
            <p>Little bit of description</p>
            <p>$50</p>
            <div class="show-contact" onclick="showContact(this)">Contact Seller</div> <!-- Contact Seller button -->
            <div class="contact-info"> <!-- Contact info -->
                <h3>Contact Information</h3>
                <p>Email: seller1@example.com</p>
                <p>Phone: +1234567890</p>
            </div>
        </div>
    </div>
    <!-- Add more products with similar structure -->
</div>

</section>

<script>
    function toggleNavbarOptions() {
    var navbarOptions = document.getElementById("navbarOptions");
    navbarOptions.style.display = navbarOptions.style.display === "block" ? "none" : "block";
    }

    function showContact(button) {
        var productInfo = button.parentElement; // Get the parent element of the button (product-info)
        var contactInfo = productInfo.querySelector('.contact-info'); // Find the contact info within the product-info

        if (contactInfo.style.display === 'block') {
            contactInfo.style.display = 'none';
        } else {
            // Set position of contact-info relative to product-info
            contactInfo.style.position = 'absolute';
            contactInfo.style.top = '0';
            contactInfo.style.left = '100%';
            contactInfo.style.display = 'block';
        }
    }

    document.addEventListener('DOMContentLoaded', function() {
        document.getElementById('advanced-filter-btn').addEventListener('click', function() {
            var form = document.getElementById('advanced-filter-form');
            if (form.style.display === 'none') {
                form.style.display = 'block';
            } else {
                form.style.display = 'none';
            }
        });
    });
</script>


</body>
</html>
