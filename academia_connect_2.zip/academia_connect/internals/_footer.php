<div class="container-fluid bg-secondary bg-gradient text-dark">
    <p class="text-center">@ Copyright AcademiaConnect 2024 | All right reserved</p>
</div>