<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "academia_connect";

$conn = mysqli_connect($servername, $username, $password, $database);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Sorting options
$sort = "ASC";
if (isset($_GET['sort'])) {
    $sort = $_GET['sort'];
}

// Query to fetch canteen menu items
$sql = "SELECT * FROM canteen_menu ORDER BY food_name $sort";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    ?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Canteen Menu</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css">
    </head>

    <body>
        <div class="container">
            <h1>Canteen Menu</h1>
            <div class="row">
                <div class="col-md-12">
                    <a href="?sort=ASC" class="btn btn-primary">Sort Ascending</a>
                    <a href="?sort=DESC" class="btn btn-primary">Sort Descending</a>
                </div>
            </div>
            <div class="row">
                <?php
                // Loop through each menu item and display it
                while ($row = mysqli_fetch_assoc($result)) {
                    ?>
                    <div class="col-md-4 mt-3">
                        <div class="card">
                            <img src="<?php echo $row['food_photo']; ?>" class="card-img-top" alt="Food Photo">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo $row['food_name']; ?></h5>
                                <p class="card-text">Price: <?php echo $row['price']; ?></p>
                            </div>
                        </div>
                    </div>
                <?php
                }
                ?>
            </div>
        </div>
    </body>

    </html>
<?php
} else {
    echo "No items found in the canteen menu.";
}

// Close database connection
mysqli_close($conn);
?>
