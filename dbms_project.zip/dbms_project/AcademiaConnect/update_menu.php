<?php
session_start();

// Redirect to login page if user is not logged in or not a canteen staff
if (!isset($_SESSION["user"]) || $_SESSION["role"] !== "canteen_staff") {
    header("Location: login.php");
    exit;
}

// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$database = "academia_connect";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$error = $success = "";

// Process form submission
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    
    // Retrieve form data
    $foodName = trim($_POST["food_name"]);
    $price = $_POST["price"];
    $foodPhoto = $_FILES["food_photo"];

    // Validate form data
    if (empty($foodName) || empty($price) || empty($foodPhoto["name"])) {
        $error = "Food name, price, and photo are required.";
    } else {
        // Directory for storing food photos
        $targetDir = "uploads/";
        $targetFilePath = $targetDir . basename($foodPhoto["name"]);
        $fileType = strtolower(pathinfo($targetFilePath, PATHINFO_EXTENSION));
        $allowedTypes = array("jpg", "jpeg", "png", "gif");

        // Check file type and size
        if (!in_array($fileType, $allowedTypes)) {
            $error = "Only JPG, JPEG, PNG, and GIF files are allowed.";
        } elseif ($foodPhoto["size"] > 5000000) { // 5MB limit
            $error = "File size is too large. Maximum size allowed is 5MB.";
        } else {
            // Check if food item already exists
            $stmt = $conn->prepare("SELECT * FROM canteen_menu WHERE food_name = ?");
            $stmt->bind_param("s", $foodName);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $error = "Food item already exists in the menu.";
            } else {
                // Insert new food item into the database
                $stmt = $conn->prepare("INSERT INTO canteen_menu (food_name, price, food_photo) VALUES (?, ?, ?)");
                $stmt->bind_param("sis", $foodName, $price, $targetFilePath);

                if ($stmt->execute()) {
                    // Upload food photo
                    if (move_uploaded_file($foodPhoto["tmp_name"], $targetFilePath)) {
                        $success = "Food item added successfully.";
                    } else {
                        $error = "Error uploading food photo.";
                    }
                } else {
                    $error = "Error adding food item to the menu.";
                }
            }
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Menu</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: Arial, sans-serif;
        }
        .container {
            margin-top: 50px;
        }
        h1 {
            margin-bottom: 30px;
            color: #007bff;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="mt-5">Update Menu</h1>
        <?php if (isset($error)) : ?>
            <div class="alert alert-danger" role="alert">
                <?php echo $error; ?>
            </div>
        <?php endif; ?>
        <?php if (isset($success)) : ?>
            <div class="alert alert-success" role="alert">
                <?php echo $success; ?>
            </div>
        <?php endif; ?>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST" enctype="multipart/form-data">
            <div class="mb-3">
                <label for="food_name" class="form-label">Food Name:</label>
                <input type="text" name="food_name" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="price" class="form-label">Price:</label>
                <input type="number" name="price" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="food_photo" class="form-label">Food Photo:</label>
                <input type="file" name="food_photo" class="form-control" accept="image/*" required>
            </div>
            <button type="submit" class="btn btn-primary">Add Item</button>
        </form>
    </div>
</body>
</html>
