<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "academia_connect";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables
$id = $day = $exercise_name = $time = "";
$days = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
$successMessage = $errorMessage = "";

// Handle form submission for adding/updating classes
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = intval($_POST['id']);
    $day = $conn->real_escape_string($_POST['day']);
    $exercise_name = $conn->real_escape_string($_POST['exercise_name']);
    $time = $conn->real_escape_string($_POST['time']);

    if ($id > 0) {
        // Update existing class
        $sql = "UPDATE classes SET day='$day', exercise_name='$exercise_name', time='$time' WHERE id='$id'";
        if ($conn->query($sql) === TRUE) {
            $successMessage = "Class updated successfully!";
        } else {
            $errorMessage = "Error updating class: " . $conn->error;
        }
    } else {
        // Add new class
        $sql = "INSERT INTO classes (day, exercise_name, time) VALUES ('$day', '$exercise_name', '$time')";
        if ($conn->query($sql) === TRUE) {
            $successMessage = "Class added successfully!";
        } else {
            $errorMessage = "Error adding class: " . $conn->error;
        }
    }
}

// Fetch class data for editing if id is provided
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $sql = "SELECT * FROM classes WHERE id='$id'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $class = $result->fetch_assoc();
        $day = $class['day'];
        $exercise_name = $class['exercise_name'];
        $time = $class['time'];
    } else {
        $errorMessage = "Class not found!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Classes</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <style>
        body {
            background: linear-gradient(45deg, #FFA500, #FF4500);
            color: #fff;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background: linear-gradient(45deg, #808080, #A9A9A9);
            color: #000;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.4);
        }
        .btn-primary {
            width: 100%;
            background: linear-gradient(45deg, #333, #555);
            border: none;
            margin-top: 10px;
        }
        .btn-primary:hover {
            background: linear-gradient(45deg, #555, #777);
        }
        .form-control {
            width: 100%;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="mt-5"><?php echo isset($_GET['id']) ? 'Edit Class' : 'Add Class'; ?></h1>
        <?php
        if ($successMessage) {
            echo "<div class='alert alert-success'>$successMessage</div>";
        }
        if ($errorMessage) {
            echo "<div class='alert alert-danger'>$errorMessage</div>";
        }
        ?>
        <form method="post">
            <input type="hidden" name="id" value="<?php echo $id; ?>">
            <div class="form-group">
                <label for="day">Day</label>
                <select name="day" class="form-control" required>
                    <?php
                    foreach ($days as $d) {
                        $selected = $d == $day ? 'selected' : '';
                        echo "<option value='$d' $selected>" . ucfirst($d) . "</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="form-group">
                <label for="exercise_name">Exercise Name</label>
                <input type="text" name="exercise_name" class="form-control" value="<?php echo htmlspecialchars($exercise_name); ?>" required>
            </div>
            <div class="form-group">
                <label for="time">Time</label>
                <input type="text" name="time" class="form-control" value="<?php echo htmlspecialchars($time); ?>" required>
            </div>
            <button type="submit" class="btn btn-primary"><?php echo isset($_GET['id']) ? 'Update Class' : 'Add Class'; ?></button>
        </form>
    </div>
</body>
</html>

<?php
$conn->close();
?>
