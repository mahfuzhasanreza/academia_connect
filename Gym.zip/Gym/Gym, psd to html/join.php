<?php
$servername = "localhost"; 
$username = "root";
$password = ""; 
$dbname = "academia_connect"; 

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$admitted = false;
$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $phone_no = $_POST['phone_no'];
    $plan_type = $_POST['plan_type'];

    $sql = "INSERT INTO members (first_name, last_name, phone_no, plan_type) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssss", $first_name, $last_name, $phone_no, $plan_type);

    if ($stmt->execute()) {
        $admitted = true;
    } else {
        $error = $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Join Gym</title>
    <!-- Bootstrap CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    
    <style>

        @keyframes gradientBackground {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        @keyframes sparkle {
            0% { background-position: 0% 0%; }
            50% { background-position: 100% 100%; }
            100% { background-position: 0% 0%; }
        }

        body {
          background: linear-gradient(270deg, #ff7e5f, #feb47b, #ff7e5f);
          background-size: 600% 600%;
          animation: gradientBackground 10s ease infinite;
          height: 100vh;
          display: flex;
          justify-content: center;
          align-items: center;
       }

      .container {
          background: rgba(255, 255, 255, 0.6); 
          padding: 30px; 
          border-radius: 15px; 
          border: 1px solid rgba(0, 0, 0, 0.4); 
          box-shadow: 0 8px 20px rgba(0, 0,  0, 0.4);
          position: relative;
          z-index: 1;
         }


        .sparkle {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('https://www.transparenttextures.com/patterns/stardust.png');
            opacity: 0.6; 
            animation: sparkle 15s linear infinite; 
            background-size: 200% 200%;  
            z-index: 0; 
        }
    </style>
</head>
<body>
    <div class="container mt-5 position-relative sparkle">
        <?php if ($admitted): ?>
            <div class='alert alert-success' role='alert'>Admitted successfully!</div>
            <script>
                setTimeout(function() {
                    window.location.href = 'index.php';
                }, 3000); // Redirects after 3 seconds
            </script>
        <?php else: ?>
            <h2 class="text-center">Join Now</h2>
            <?php if (!empty($error)): ?>
                <div class='alert alert-danger' role='alert'>Error: <?php echo $error; ?></div>
            <?php endif; ?>
            <form action="join.php" method="post" class="needs-validation" novalidate>
                <div class="form-group">
                    <label for="first_name">First Name:</label>
                    <input type="text" class="form-control" id="first_name" name="first_name" required>
                    <div class="invalid-feedback">Please enter your first name.</div>
                </div>
                <div class="form-group">
                    <label for="last_name">Last Name:</label>
                    <input type="text" class="form-control" id="last_name" name="last_name" required>
                    <div class="invalid-feedback">Please enter your last name.</div>
                </div>
                <div class="form-group">
                    <label for="phone_no" >Phone Number:</label>
                    <input type="text" class="form-control" id="phone_no" name="phone_no" autocomplete="off" required>
                    <div class="invalid-feedback">Please enter your phone number.</div>
                </div>
                <div class="form-group">
                    <label for="plan_type">Plan:</label>
                    <select class="form-control" id="plan_type" name="plan_type" required>
                        <option value="Regular">Regular</option>
                        <option value="Premium">Premium</option>
                        <option value="VIP">VIP</option>
                    </select>
                    <div class="invalid-feedback">Please select a plan.</div>
                </div>
                <button type="submit" class="btn btn-primary" style="width: 100%; background: linear-gradient(to right, #434343, #000000); border: none;">Join</button>
            </form>
        <?php endif; ?>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <!-- Form validation script -->
    <script>
    (function() {
        'use strict';
        window.addEventListener('load', function() {
            var forms = document.getElementsByClassName('needs-validation');
            var validation = Array.prototype.filter.call(forms, function(form) {
                form.addEventListener('submit', function(event) {
                    if (form.checkValidity() === false) {
                        event.preventDefault();
                        event.stopPropagation();
                    }
                    form.classList.add('was-validated');
                }, false);
            });
        }, false);
    })();
    </script>
</body>
</html>
