<?php
$servername = "localhost"; 
$username = "root";
$password = ""; 
$dbname = "academia_connect"; 

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle delete action
$deleteMessage = "";
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);

    // Delete related records in trainer_social_link table first
    $sql_delete_social_links = "DELETE FROM trainer_social_link WHERE trainer_id='$id'";
    if ($conn->query($sql_delete_social_links) === TRUE) {
        // Now delete the trainer record
        $sql = "DELETE FROM trainers WHERE id='$id'";
        if ($conn->query($sql) === TRUE) {
            $deleteMessage = "Trainer deleted successfully!";
        } else {
            $deleteMessage = "Error deleting trainer: " . $conn->error;
        }
    } else {
        $deleteMessage = "Error deleting social links: " . $conn->error;
    }
}

// Fetch trainers
$sql = "SELECT * FROM trainers";
$result = $conn->query($sql);
$numTrainers = $result->num_rows;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Trainers</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <style>
        body {
            background: linear-gradient(45deg, #FFA500, #FF4500);
            color: #fff;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: linear-gradient(45deg, #808080, #A9A9A9);
            color: #000;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.4);
            max-width: 800px;
            overflow: auto;
            height: 70%;
        }
        .btn-primary, .btn-danger {
            width: 100%;
            background: linear-gradient(45deg, #333, #555);
            border: none;
            margin-bottom: 10px;
        }
        .btn-primary:hover, .btn-danger:hover {
            background: linear-gradient(45deg, #555, #777);
        }
        .form-control {
            width: 100%;
        }
        .table th {
            background-color: #333;
            color: #fff;
            position: sticky;
            top: -20px;
        }
        .alert {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            z-index: 1000;
            display: none;
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 10px;
            border-radius: 5px;
        }
        .close-btn {
            position: absolute;
            top: 10px;
            right: 10px;
            font-size: 24px;
            color: #fff;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="mt-5">Trainers List (Total: <?php echo $numTrainers; ?>)</h1>
        <a href="index.php" class="close-btn">&times;</a>
        <div class="alert" id="alert"><?php echo $deleteMessage; ?></div>
        <table class="table table-bordered mt-3">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Designation</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo '<tr>
                            <td>' . $row['id'] . '</td>
                            <td>' . htmlspecialchars($row['name']) . '</td>
                            <td>' . htmlspecialchars($row['designation']) . '</td>
                            <td>
                                <a href="edit_trainer.php?id=' . $row['id'] . '" class="btn btn-primary">Update</a>
                                <a href="?delete=' . $row['id'] . '" class="btn btn-danger" onclick="return confirm(\'Are you sure?\')">Delete</a>
                            </td>
                        </tr>';
                    }
                } else {
                    echo '<tr><td colspan="4">No trainers found</td></tr>';
                }
                ?>
            </tbody>
        </table>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var alert = document.getElementById('alert');
            if (alert.textContent.trim() !== "") {
                alert.style.display = 'block';
                setTimeout(function() {
                    alert.style.display = 'none';
                }, 1500);
            }
        });
    </script>
</body>
</html>

<?php
$conn->close();
?>
