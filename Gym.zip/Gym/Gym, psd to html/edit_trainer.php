<?php
$servername = "localhost"; 
$username = "root";
$password = ""; 
$dbname = "academia_connect"; 

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize $trainer and $trainer_social_link variables
$trainer = array(
    'id' => '',
    'name' => '',
    'description' => '',
    'designation' => '',
    'photo_url' => ''
);
$trainer_social_link = array(
    'facebook_link' => '',
    'x_link' => '',
    'linkedin_link' => ''
);

// Get trainer data if id is provided
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $sql_trainer = "SELECT * FROM trainers WHERE id='$id'";
    $result_trainer = $conn->query($sql_trainer);

    if ($result_trainer->num_rows > 0) {
        $trainer = $result_trainer->fetch_assoc();
    } else {
        echo "Trainer not found!";
        exit();
    }

    // Get trainer social link
    $sql_social_links = "SELECT * FROM trainer_social_link WHERE trainer_id='$id'";
    $result_social_link = $conn->query($sql_social_links);
    if ($result_social_link->num_rows > 0) {
        $trainer_social_link = $result_social_link->fetch_assoc();
    }
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = intval($_POST['id']);
    $name = $conn->real_escape_string($_POST['name']);
    $description = $conn->real_escape_string($_POST['description']);
    $designation = $conn->real_escape_string($_POST['designation']);

    // Check if a file was uploaded
    if ($_FILES["photo"]["name"]) {
        $photo_data = addslashes(file_get_contents($_FILES["photo"]["tmp_name"]));
    } else {
        $photo_data = $trainer['photo_url'];
    }

    // Update trainer details
    $sql_update_trainer = "UPDATE trainers SET name='$name', description='$description', designation='$designation', photo_url='$photo_data' WHERE id='$id'";
    if ($conn->query($sql_update_trainer) === TRUE) {
        // Update trainer social link
        $facebook_link = $conn->real_escape_string($_POST['facebook_link']);
        $x_link = $conn->real_escape_string($_POST['x_link']);
        $linkedin_link = $conn->real_escape_string($_POST['linkedin_link']);
        $sql_update_social_links = "UPDATE trainer_social_link SET facebook_link='$facebook_link', x_link='$x_link', linkedin_link='$linkedin_link' WHERE trainer_id='$id'";
        $conn->query($sql_update_social_links);

        echo "Trainer updated successfully!";
        header("Location: view_trainers.php");
        exit();
    } else {
        echo "Error updating record: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Trainer</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <style>
        body {
            background: linear-gradient(45deg, #FFA500, #FF4500);
            color: #fff;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background: linear-gradient(45deg, #808080, #A9A9A9);
            color: #000;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.4);
        }
        .btn-primary {
            width: 100%;
            background: linear-gradient(45deg, #333, #555);
            border: none;
            margin-top: 10px;
        }
        .btn-primary:hover {
            background: linear-gradient(45deg, #555, #777);
        }
        .form-control {
            width: 100%;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="mt-5">Edit Trainer</h1>
        <form method="post" enctype="multipart/form-data">
            <input type="hidden" name="id" value="<?php echo $trainer['id']; ?>">
            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" name="name" class="form-control" value="<?php echo $trainer['name']; ?>" required>
            </div>
            <div class="form-group">
                <label for="description">Description</label>
                <textarea name="description" class="form-control" required><?php echo $trainer['description']; ?></textarea>
            </div>
            <div class="form-group">
                <label for="designation">Designation</label>
                <input type="text" name="designation" class="form-control" value="<?php echo $trainer['designation']; ?>" required>
            </div>
            <div class="form-group">
                <label for="photo">Photo</label>
                <input type="file" name="photo" class="form-control-file">
            </div>
            <!-- Social Links Section -->
            <div class="form-group">
                <label for="facebook_link">Facebook Link</label>
                <input type="text" name="facebook_link" class="form-control" value="<?php echo $trainer_social_link['facebook_link']; ?>">
            </div>
            <div class="form-group">
                <label for="x_link">X Link</label>
                <input type="text" name="x_link" class="form-control" value="<?php echo $trainer_social_link['x_link']; ?>">
            </div>
            <div class="form-group">
                <label for="linkedin_link">LinkedIn Link</label>
                <input type="text" name="linkedin_link" class="form-control" value="<?php echo $trainer_social_link['linkedin_link']; ?>">
            </div>
            <button type="submit" class="btn btn-primary">Update Trainer</button>
        </form>
    </div>
</body>
</html>
