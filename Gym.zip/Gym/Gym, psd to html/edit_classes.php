<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "academia_connect";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Define a variable to hold potential success or error messages
$message = "";

// If the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve the form data
    $id = $_POST["id"];
    $exercise_name = $conn->real_escape_string($_POST["exercise_name"]);
    $time = $conn->real_escape_string($_POST["time"]);

    // Update the database with the new values
    $sql = "UPDATE classes SET exercise_name='$exercise_name', time='$time' WHERE id='$id'";

    if ($conn->query($sql) === TRUE) {
        $message = "Record updated successfully";
    } else {
        $message = "Error updating record: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Classes</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <style>
        body {
            background: linear-gradient(45deg, #FFA500, #FF4500);
            color: #fff;
            margin: 0;
        }

        .container {
            padding: 50px;
            max-width: 1100px;
            margin: auto;
        }

        .floating-window {
            background: linear-gradient(45deg, #808080, #A9A9A9);
            border: 2px solid #333;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
        }

        .table {
            margin-top: 20px;
        }

        .message {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: #000;
            color: #fff;
            padding: 10px 20px;
            border-radius: 5px;
            z-index: 9999;
            display: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="floating-window">
            <h2 class="text-center mb-4">Edit Classes</h2>
            <?php if ($message): ?>
                <div class="message"><?php echo $message; ?></div>
            <?php endif; ?>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Day</th>
                            <th>Exercise Name</th>
                            <th>Time</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $sql = "SELECT id, day, exercise_name, time FROM classes";
                        $result = $conn->query($sql);

                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                echo "<tr>
                                        <td>{$row['day']}</td>
                                        <td>{$row['exercise_name']}</td>
                                        <td>{$row['time']}</td>
                                        <td>
                                            <form method='post'>
                                                <input type='hidden' name='id' value='{$row['id']}'>
                                                <input type='text' name='exercise_name' value='{$row['exercise_name']}'>
                                                <input type='text' name='time' value='{$row['time']}'>
                                                <button type='submit' class='btn btn-primary'>Update</button>
                                            </form>
                                        </td>
                                    </tr>";
                            }
                        } else {
                            echo "<tr><td colspan='4'>No classes available</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</body>
</html>
