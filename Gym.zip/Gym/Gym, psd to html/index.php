<?php
    $servername = "localhost"; 
    $username = "root";
    $password = ""; 
    $dbname = "academia_connect"; 

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" integrity="sha512-5A8nwdMOWrSz20fDsjczgUidUBR8liPYU+WymTZP1lmY9G6Oc7HlZv156XqnsgNUzTyMefFTcsFH/tnJE/+xBg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="css/venobox.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/slick.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    <title>Gym</title>
</head>
<body>

    <!----------------------------------------------------
                      Navbar part start
    ----------------------------------------------------->

    <nav class="navbar navbar-expand-lg main-menu py-0">
        <div class="container px-0">
          <a class="navbar-brand py-0" href="#">
              <img src="images/logo.png" alt="logo">
          </a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <i class="fa fa-bars" aria-hidden="true"></i>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="#">Home</a>
              </li>
              <li class="nav-item">
                <li class="nav-item">
                    <a class="nav-link" href="#about">About us</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#gallery">gallary</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#team">team</a>
                </li>
                  <li class="nav-item">
                    <a class="nav-link" href="#testimonial">testimonial</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#membership">membership</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#classes">classes</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#footer">contact</a>
                </li>
            </ul>
          </div>
        </div>
      </nav>

    <!----------------------------------------------------
                   Navbar part end
    ----------------------------------------------------->


    <!----------------------------------------------------
                  Banner part start
    ----------------------------------------------------->

    <section id="banner">
      <div class="banner-item" style="background: url(images/banner.jpg) no-repeat center; background-size: cover;">
        <div class="container">
          <div class="row">
            <div class="col-lg-6 m-auto text-center">
              <div class="banner-text">
                <h2>Time to start</h2>
                <h1>gymnasium</h1>
                <p>Your body can stand almost anything. It's your mind that you have to convince.</p>
                <a href="join.php">join now</a>
                <a href="#footer">view more</a>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="banner-item" style="background: url(images/banner-2.jpeg) no-repeat center; background-size: cover;">
        <div class="container">
          <div class="row">
            <div class="col-lg-6 m-auto text-center">
              <div class="banner-text">
                <h2>Time to start</h2>
                <h1>gymnasium</h1>
                <p>Your body can stand almost anything. It's your mind that you have to convince.</p>
                <a href="join.php">join now</a>
                <a href="#">view more</a>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="banner-item" style="background: url(images/banner.jpg) no-repeat center; background-size: cover;">
        <div class="container">
          <div class="row">
            <div class="col-lg-6 m-auto text-center">
              <div class="banner-text">
                <h2>Time to start</h2>
                <h1>gymnasium</h1>
                <p>Your body can stand almost anything. It's your mind that you have to convince.</p>
                <a href="">join now</a>
                <a href="#">view more</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!----------------------------------------------------
                   Banner part end
    ----------------------------------------------------->


    <!----------------------------------------------------
                 About  part start
    ----------------------------------------------------->
    <section id="about">
      <div class="container">
        <div class="row">
          <div class="col-lg-6 order-2 order-lg-1">
            <div class="about-img">
              <img src="images/about.jpg" alt="Image"  class="img-fluid w-100">
              <div class="about-overlay">
                <div class="about-icon">
                  <a class="venobox" data-autoplay="true" data-vbtype="video" href="https://youtu.be/X_9VoqR5ojM">
                    <i class="fa fa-play" aria-hidden="true"></i>
                  </a>
                </div>
              </div>
            </div>
          </div>
            <div class="col-lg-6 order-1 oeder-lg-2">
              <div class="common-head text-center">
                <h2>About us</h2>
                <img src="images/shape.png" alt="shape">
              </div>
              <div class="about-text">
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatem quos, soluta enim nemo harum recusandae a temporibus veritatis
                   dolores delectus explicabo nisi quia vitae et itaque dolore sint repellat illum laudantium ipsam atque perferendis natus exercitati
                   onem expedita! Aliquam blanditiis velit hic harum tenetur, debitis doloremque nemo asperiores tempora neque, quia non et commodi eo
                   s, voluptas quidem aperiam laborum provident aspernatur
                   
                   <span>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nobis aut nisi similique laboriosam itaque! Sunt aliquid accusantium, est corporis unde voluptates quia ullam excepturi rem. Quod facere sequi cupiditate ipsam quos corporis reiciendis deserunt repudiandae dolorum officiis officia illo quasi necessitatibus maxime, repellendus cumque quidem a doloremque ullam! Sit, nam? Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ullam vitae natus, debitis tempore architecto laborum.</span>.</p>
              </div>
            </div>
          </div>
      </div>
    </section>

    <!----------------------------------------------------
                 About  part end
    ----------------------------------------------------->



    <!----------------------------------------------------
                 Gallery  part start
    ----------------------------------------------------->

    <section id="gallery">
      <div class="common-head gal-head text-center">
        <h2>our gallery</h2>
        <img src="images/shape.png" alt="shape">
      </div>
      <div class="gal-bg" style="background: url(images/gal-bg.jpg) no-repeat center; background-size: cover;">
        <div class="container">
          <div class="row">
            <div class="col-lg-4">
              <div class="gal-img">
                <img src="images/gal-1.jpg" alt="gallery" class="img-fluid w-100">
                <div class="gal-overlay">
                  <div class="gal-icon">
                    <a class="venobox" data-gall="gallery01" href="images/gal-1.jpg">
                      <i class="fa fa-search-plus" aria-hidden="true"></i>
                    </a>
                      </div>
                  </div>
                </div>
                <div class="gal-img">
                  <img src="images/gal-2.jpg" alt="gallery" class="img-fluid w-100">
                  <div class="gal-overlay">
                    <div class="gal-icon">
                      <a class="venobox" data-gall="gallery01" href="images/gal-2.jpg">
                         <i class="fa fa-search-plus" aria-hidden="true"></i>
                      </a>
                      </div>
                    </div>
                 </div>
            </div>
            <div class="col-lg-4">
              <div class="gal-img">
                <img src="images/gal-3.jpg" alt="gallery" class="img-fluid w-100">
                <div class="gal-overlay">
                  <div class="gal-icon">
                    <a class="venobox" data-gall="gallery01" href="images/gal-2.jpg">
                       <i class="fa fa-search-plus" aria-hidden="true"></i>
                    </a>
                      </div>
                  </div>
                </div>
                <div class="gal-img">
                  <img src="images/gal-4.jpg" alt="gallery" class="img-fluid w-100">
                  <div class="gal-overlay">
                    <div class="gal-icon">
                      <a class="venobox" data-gall="gallery01" href="images/gal-1.jpg">
                         <i class="fa fa-search-plus" aria-hidden="true"></i>
                      </a>
                      </div>
                    </div>
                 </div>
            </div>
            <div class="col-lg-4">
              <div class="gal-img">
                <img src="images/gal-5.jpg" alt="gallery" class="img-fluid w-100">
                <div class="gal-overlay">
                  <div class="gal-icon">
                    <a class="venobox" data-gall="gallery01" href="images/gal-1.jpg">
                       <i class="fa fa-search-plus" aria-hidden="true"></i>
                    </a>
                      </div>
                  </div>
                </div>
                <div class="gal-img">
                  <img src="images/gal-6.jpg" alt="gallery" class="img-fluid w-100">
                  <div class="gal-overlay">
                    <div class="gal-icon">
                      <a class="venobox" data-gall="gallery01" href="images/gal-2.jpg">
                         <i class="fa fa-search-plus" aria-hidden="true"></i>
                      </a>
                      </div>
                    </div>
                 </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!----------------------------------------------------
                  Gallery  part end
    ----------------------------------------------------->


    <!----------------------------------------------------
                 Trainers part start
    ----------------------------------------------------->

<section id="team">
    <div class="common-head team-head text-center">
        <h2>Our Team</h2>
        <img src="images/shape.png" alt="shape">
    </div>
    <div class="container">
        <div class="row">
            <?php
            // Assuming $conn is your database connection
            $servername = "localhost"; 
            $username = "root";
            $password = ""; 
            $dbname = "gymnasium"; 

            // Create connection
            $conn = new mysqli($servername, $username, $password, $dbname);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            $sql = "SELECT t.id, t.name, t.designation, t.description, tsl.facebook_link, tsl.x_link, tsl.linkedin_link 
                    FROM trainers t
                    LEFT JOIN trainer_social_link tsl ON t.id = tsl.trainer_id";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo '
                    <div class="col-lg-3 col-md-4 col-sm-6">
                        <div class="team-main">
                            <div class="team-img">
                                <img src="display_image.php?id=' . $row["id"] . '" alt="image" class="img-fluid w-100 team-photo">
                                <div class="team-overlay">
                                    <div class="team-icon">
                                        <ul>';
                    if ($row["facebook_link"]) {
                        echo '<li><a href="' . htmlspecialchars($row["facebook_link"]) . '"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>';
                    }
                    if ($row["x_link"]) {
                        echo '<li><a href="' . htmlspecialchars($row["x_link"]) . '"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>'; // Retaining Twitter icon
                    }
                    if ($row["linkedin_link"]) {
                        echo '<li><a href="' . htmlspecialchars($row["linkedin_link"]) . '"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>';
                    }
                    echo '
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="team-text text-center">
                                <h2>' . htmlspecialchars($row["name"]) . '</h2>
                                <h3>' . htmlspecialchars($row["designation"]) . '</h3>
                                <p>' . htmlspecialchars($row["description"]) . '</p>
                            </div>
                        </div>
                    </div>';
                }
            } else {
                echo '<p>No trainers found</p>';
            }
            ?>
        </div>
    </div>

    
    <style>
        .team-main {
            margin-bottom: 30px;
        }
        .team-img {
            position: relative;
            overflow: hidden;
        }
        .team-photo {
            height: 300px; 
            object-fit: cover; 
        }

        .team-overlay {
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          background: rgba(255, 0, 0, 0.5); /* Red overlay with 50% opacity */
          display: flex;
          justify-content: center;
          align-items: center;
          opacity: 0;
          transition: opacity 0.5s ease;
        }

          .team-main:hover .team-overlay {
              opacity: 1;
          }
        .team-icon ul {
            list-style: none;
            padding: 0;
            margin: 0;
            display: flex;
        }
        .team-icon ul li {
            margin: 0 5px;
        }
        .team-icon ul li a {
            color: #fff;
            font-size: 20px;
        }
        .team-text h2, .team-text h3 {
            margin: 10px 0;
        }
    </style>
</section>



    <!----------------------------------------------------
                   Trainers part end
    ----------------------------------------------------->

    <!----------------------------------------------------
                  testimonial part start
    ----------------------------------------------------->


<?php
$trainers = [];
$sql = "SELECT id, name, designation, description FROM trainers";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $trainers[] = $row;
    }
}
?>

<section id="testimonial">
    <div class="common-head text-center">
        <h2>Testimonial</h2>
        <img src="images/shape.png" alt="shape">
    </div>
    <div class="test-bg" style="background: url(images/test-bg.jpg) no-repeat center; background-size: cover;">
        <div class="container">
            <div id="testimonialCarousel" class="carousel slide" data-ride="carousel">
                <div class="carousel-inner">
                    <?php foreach ($trainers as $index => $trainer): ?>
                        <div class="carousel-item <?php if ($index === 0) echo 'active'; ?>">
                            <div class="row justify-content-center">
                                <div class="col-lg-8 text-center testimonial-name">
                                    <img src="display_image.php?id=<?php echo $trainer['id']; ?>" alt="image" class="img-fluid rounded-circle mb-4" style="width: 150px; height: 150px;">
                                    <h2><?php echo htmlspecialchars($trainer['name']); ?></h2>
                                    <h3><?php echo htmlspecialchars($trainer['designation']); ?></h3>
                                    <div class="test-icon">
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                    </div>
                                    <div class="test-para mt-3">
                                        <p><?php echo htmlspecialchars($trainer['description']); ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                <a class="carousel-control-prev" href="#testimonialCarousel" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#testimonialCarousel" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div>
        </div>
    </div>
</section>


    <!----------------------------------------------------
                  Testimonial part end
    ----------------------------------------------------->

    <!----------------------------------------------------
                  Membership part start
    ----------------------------------------------------->
    
<section id="membership">
  <div class="common-head m-head text-center">
    <h2>Membership</h2>
    <img src="images/shape.png" alt="shape">
  </div>
  <div class="container">
    <div class="row">
      <?php
      $sql = "SELECT membership_type, price FROM membership_types";
      $result = $conn->query($sql);

      if ($result->num_rows > 0) {
        $memberships = [];
        while ($row = $result->fetch_assoc()) {
          $memberships[trim($row["membership_type"])] = $row["price"];
        }


        $membershipFeatures = [
          "Regular" => ["Free tutorial", "Aerobik Programmes", "X", "X", "X"],
          "Premium" => ["Free tutorial", "Aerobik Programmes", "Trainer Support", "X", "X"],
          "VIP" => ["Free tutorial", "Aerobik Programmes", "Trainer Support", "Free Consultation", "Personal Trainer"]
        ];

        $membershipTitles = [
          "Regular" => "Regular Membership",
          "Premium" => "Premium Membership",
          "VIP" => "VIP Premium Membership"
        ];

        foreach ($membershipTitles as $type => $title) {
          $price = isset($memberships[$type]) ? $memberships[$type] : 'N/A';
          echo '<div class="col-lg-4">
                  <div class="membership-item text-center">
                    <h3>' . $title . '</h3>
                    <h2>$' . $price . '<span>/Month</span></h2>
                    <ul>';
          foreach ($membershipFeatures[$type] as $feature) {
            echo '<li>' . $feature . '</li>';
          }
          echo '    </ul>
                    <a href="join.php">Join Now</a>
                  </div>
                </div>';
        }
      } else {
        echo '<p>No membership types found</p>';
      }
      ?>
    </div>
  </div>
</section>


    <!----------------------------------------------------
                  Membership part end
    ----------------------------------------------------->

    <!----------------------------------------------------
                  Counter part start
    ----------------------------------------------------->

    <section id="counter">
      <div class="container">
        <div class="row">
          <div class="col">
            <div class="counter-item">
              <h2 class="counter">261</h2>
              <p>Cup of tea</p>
            </div>
          </div>
          <div class="col">
            <div class="counter-item">
              <h2 class="counter">518</h2>
              <p>Got trained</p>
            </div>
          </div>
          <div class="col">
            <div class="counter-item">
              <h2 class="counter">650</h2>
              <p>Members Joined</p>
            </div>
          </div>
          <div class="col">
            <div class="counter-item">
              <h2 class="counter">500</h2>
              <p>Premiums</p>
            </div>
          </div>
          <div class="col">
            <div class="counter-item">
              <h2 class="counter">499</h2>
              <p>VIP</p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!----------------------------------------------------
                   Counter part end
    ----------------------------------------------------->


    <!----------------------------------------------------
                   Classes part start
    ----------------------------------------------------->


<section id="classes">
  <div class="common-head classes-head text-center">
    <h2>Our Classes</h2>
    <img src="images/shape.png" alt="shape">
  </div>
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <ul class="nav nav-pills mb-3 class-tab" id="pills-tab" role="tablist">
          <?php
          $days = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
          foreach ($days as $index => $day) {
            $active = $index === 0 ? 'active' : '';
            echo "<li class='nav-item' role='presentation'>
                    <button class='nav-link $active' id='$day' data-bs-toggle='pill' data-bs-target='#$day-text' type='button' role='tab' aria-controls='$day-text' aria-selected='true'>" . ucfirst($day) . "</button>
                  </li>";
          }
          ?>
        </ul>

        <div class="tab-content tab-body" id="pills-tabContent">
          <?php
          foreach ($days as $index => $day) {
            $active = $index === 0 ? 'show active' : 'fade';
            echo "<div class='tab-pane $active' id='$day-text' role='tabpanel' aria-labelledby='$day'>";
            echo "<ul>";

            $sql = "SELECT exercise_name, time FROM classes WHERE day='$day'";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
              while ($row = $result->fetch_assoc()) {
                echo "<li>
                        <p>{$row['exercise_name']}</p>
                        <p>{$row['time']}</p>
                      </li>";
              }
            } else {
              echo "<li><p>No classes available</p></li>";
            }

            echo "</ul>";
            echo "</div>";
          }
          ?>
        </div>

      </div>
    </div>
  </div>
</section>


 

    <!----------------------------------------------------
                   Classes part end
    ----------------------------------------------------->

    
    <!----------------------------------------------------
                   Sponsor part start
    ----------------------------------------------------->

    <section id="sponsor">
      <div class="container">
        <div class="row sponsor-slider">
          <div class="col">
            <img src="images/sponsor-1.jpg" alt="sponsor" class="img-fluid w-100">
          </div>
          <div class="col">
            <img src="images/sponsor-2.jpg" alt="sponsor" class="img-fluid w-100">
          </div>
          <div class="col">
            <img src="images/sponsor-3.jpg" alt="sponsor" class="img-fluid w-100">
          </div>
          <div class="col">
            <img src="images/sponsor-4.jpg" alt="sponsor" class="img-fluid w-100">
          </div>
          <div class="col">
            <img src="images/sponsor-5.jpg" alt="sponsor" class="img-fluid w-100">
          </div>
          <div class="col">
            <img src="images/sponsor-1.jpg" alt="sponsor" class="img-fluid w-100">
          </div>
          <div class="col">
            <img src="images/sponsor-2.jpg" alt="sponsor" class="img-fluid w-100">
          </div>
        </div>
      </div>
    </section>


    <!----------------------------------------------------
                   Sponsor part end
    ----------------------------------------------------->

    
    <!----------------------------------------------------
                  Footer  part start
    ----------------------------------------------------->

    <section id="footer">
      <div class="first-part">
        <div class="footer-logo text-center">
          <img src="images/logo.png" alt="logo">
        </div>
      </div>
      <div class="mid-part">
        <div class="container">
          <div class="row">
            <div class="col-lg-3">
              <div class="footer-head">
                <h2>Opening hours</h2>
              </div>
              <div class="row">
                <div class="col-lg-4 footer-first-text">
                  <p>Monday</p>
                  <p>Tuesday</p>
                  <p>Wednesday</p>
                  <p>Thursday</p>
                  <p>Friday</p>
                  <p>Saturday</p>
                  <p>Sunday</p>
                  <p>Holiday</p>
                </div>
                <div class="col-lg-8 footer-first-text">
                  <p>05 A.M. - 11:00 p.m.</p>
                  <p>05 A.M. - 11:00 p.m.</p>
                  <p>05 A.M. - 11:00 p.m.</p>
                  <p>05 A.M. - 11:00 p.m.</p>
                  <p>05 A.M. - 11:00 p.m.</p>
                  <p>05 A.M. - 11:00 p.m.</p>
                  <p>Closed</p>
                  <p>Closed</p>
                </div>
              </div>
            </div>
            <div class="col-lg-3">
              <div class="footer-head">
                <h2>Opening hours</h2>
              </div>
              <div class="row">
                <div class="col-lg-2 footer-second-icon">
                  <i class="fa fa-twitter" aria-hidden="true"></i>
                </div>
                <div class="col-lg-10 footer-second-text">
                  <p>We want to introduce you to a new ess theme GYMNASIUM persue new press theme. This the new idea for theme, hope you will like.
                    <span>24 July 2017</span> </p>
                </div>
              </div>
              <div class="row">
                <div class="col-lg-2 footer-second-icon">
                  <i class="fa fa-twitter" aria-hidden="true"></i>
                </div>
                <div class="col-lg-10 footer-second-text">
                  <p>We want to introduce you to a new ess theme GYMNASIUM persue new press theme.
                    <span>20 July 2017</span> </p>
                </div>
              </div>
            </div>
            <div class="col-lg-3">
              <div class="footer-head">
                <h2>Flickr photos</h2>
              </div>
              <div class="row">
                <div class="col-lg-12 footer-photo">
                  <ul>
                    <li>
                      <img src="images/f-1.jpg" alt="footer-img">
                    </li>
                    <li>
                      <img src="images/f-2.jpg" alt="footer-img">
                    </li>
                    <li>
                      <img src="images/f-3.jpg" alt="footer-img">
                    </li>
                    <li>
                      <img src="images/f-4.jpg" alt="footer-img">
                    </li>
                    <li>
                      <img src="images/f-5.jpg" alt="footer-img">
                    </li>
                    <li>
                      <img src="images/f-6.jpg" alt="footer-img">
                    </li>
                    <li>
                      <img src="images/f-7.jpg" alt="footer-img">
                    </li>
                    <li>
                      <img src="images/f-8.jpg" alt="footer-img">
                    </li>
                    <li>
                      <img src="images/f-9.jpg" alt="footer-img">
                    </li>
                    <li>
                      <img src="images/f-10.jpg" alt="footer-img">
                    </li>
                    <li>
                      <img src="images/f-11.jpg" alt="footer-img">
                    </li>                    
                    <li>
                      <img src="images/f-12.jpg" alt="footer-img">
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-lg-3">
              <div class="footer-head">
                <h2>contact</h2>
              </div>
              <div class="contact-address">
                <p><i class="fa fa-map-marker" aria-hidden="true"></i>   United City, Madani Avenue, Dhaka.</p>
                <p><i class="fa fa-map-marker" aria-hidden="true"></i>   +88 01630175225, +88 017 12345675</p>
                <p><i class="fa fa-map-marker" aria-hidden="true"></i>      emon46369@gmail.com, emon99284@gmail.com </p>
              </div>
              <div class="social">
                <h2>get social</h2>
                <ul>
                  <li><i class="fa fa-facebook" aria-hidden="true"><a href="https://www.facebook.com"></a></i></li>
                  <li><i class="fa fa-twitter" aria-hidden="true"></i></li>
                  <li><i class="fa fa-linkedin" aria-hidden="true"></i></li>
                  <li><i class="fa fa-instagram" aria-hidden="true"></i></li>
                  <li><i class="fa fa-behance" aria-hidden="true"></i></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="last-part">
        <div class="footer-copyright text-center">
          <p>Copyright <i class="fa fa-copyright" aria-hidden="true"></i> All rights reserved by <span>Emon's IT institute.</span></p>
        </div>
      </div>
    </section>


    <!----------------------------------------------------
                  Footer  part end
    ----------------------------------------------------->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <script src="js/jquery-1.12.4.min.js"></script>
    <script src="js/waypoints.min.js"></script>
    <script src="js/jquery.counterup.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/venobox.min.js"></script>
    <script src="js/slick.min.js"></script>
    <script src="js/custom.js"></script>
</body>
</html>