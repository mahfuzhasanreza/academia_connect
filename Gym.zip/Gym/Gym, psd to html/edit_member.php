<?php
$servername = "localhost"; 
$username = "root";
$password = ""; 
$dbname = "academia_connect"; 

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$member = array(
    'id' => '',
    'first_name' => '',
    'last_name' => '',
    'phone_no' => '',
    'plan_type' => ''
);

// Get member data
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $sql = "SELECT * FROM members WHERE id='$id'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $member = $result->fetch_assoc();
    } else {
        echo "Member not found!";
        exit();
    }
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = intval($_POST['id']);
    $first_name = $conn->real_escape_string($_POST['first_name']);
    $last_name = $conn->real_escape_string($_POST['last_name']);
    $phone_no = $conn->real_escape_string($_POST['phone_no']);
    $plan_type = $conn->real_escape_string($_POST['plan_type']);

    $sql = "UPDATE members SET first_name='$first_name', last_name='$last_name', phone_no='$phone_no', plan_type='$plan_type' WHERE id='$id'";
    if ($conn->query($sql) === TRUE) {
        echo "Member updated successfully!";
        header("Location: members.php");
        exit();
    } else {
        echo "Error updating record: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Member</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <style>
        body {
            background: linear-gradient(45deg, #FFA500, #FF4500);
            color: #fff;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background: linear-gradient(45deg, #808080, #A9A9A9);
            color: #000;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.4);
        }
        .btn-primary {
            width: 100%;
            background: linear-gradient(45deg, #333, #555);
            border: none;
            margin-top: 10px;
        }
        .btn-primary:hover {
            background: linear-gradient(45deg, #555, #777);
        }
        .form-control {
            width: 100%;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="mt-5">Edit Member</h1>
        <form method="post">
            <input type="hidden" name="id" value="<?php echo $member['id']; ?>">
            <div class="form-group">
                <label for="first_name">First Name</label>
                <input type="text" name="first_name" class="form-control" value="<?php echo $member['first_name']; ?>" required>
            </div>
            <div class="form-group">
                <label for="last_name">Last Name</label>
                <input type="text" name="last_name" class="form-control" value="<?php echo $member['last_name']; ?>" required>
            </div>
            <div class="form-group">
                <label for="phone_no">Phone Number</label>
                <input type="text" name="phone_no" class="form-control" value="<?php echo $member['phone_no']; ?>" required>
            </div>
            <div class="form-group">
                <label for="plan_type">Plan Type</label>
                <input type="text" name="plan_type" class="form-control" value="<?php echo $member['plan_type']; ?>" required>
            </div>
            <button type="submit" class="btn btn-primary">Update Member</button>
        </form>
    </div>
</body>
</html>

<?php
$conn->close();
?>
