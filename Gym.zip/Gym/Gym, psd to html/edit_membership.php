<?php
$servername = "localhost"; 
$username = "root";
$password = ""; 
$dbname = "academia_connect"; 

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    foreach ($_POST['memberships'] as $id => $membership) {
        $type = $conn->real_escape_string($membership['membership_type']);
        $price = $conn->real_escape_string($membership['price']);

        $sql = "UPDATE membership_types SET membership_type='$type', price='$price' WHERE id='$id'";
        if ($conn->query($sql) === FALSE) {
            echo "Error updating record: " . $conn->error;
        }
    }
    echo "Memberships updated successfully!";
    header("Location: index.php");
    exit();
}

// Fetch memberships
$sql = "SELECT * FROM membership_types";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Memberships</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <style>
        body {
            background: linear-gradient(45deg, #3a3a3a, #1a1a1a);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background: rgba(255, 255, 255, 0.8);
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.4);
        }
        .btn-primary {
            width: 100%;
            background: linear-gradient(45deg, #333, #555);
            border: none;
        }
        .btn-primary:hover {
            background: linear-gradient(45deg, #555, #777);
        }
        .form-control {
            width: 100%;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="mt-5">Edit Membership Types and Prices</h1>
        <form method="post">
            <table class="table table-bordered mt-3">
                <thead>
                    <tr>
                        <th>Membership Type</th>
                        <th>Price ($)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo '<tr>
                                <td>
                                    <input type="text" name="memberships[' . $row['id'] . '][membership_type]" class="form-control" value="' . $row['membership_type'] . '">
                                </td>
                                <td>
                                    <input type="number" step="0.01" name="memberships[' . $row['id'] . '][price]" class="form-control" value="' . $row['price'] . '">
                                </td>
                            </tr>';
                        }
                    } else {
                        echo '<tr><td colspan="2">No memberships found</td></tr>';
                    }
                    ?>
                </tbody>
            </table>
            <button type="submit" class="btn btn-primary">Update Memberships</button>
        </form>
    </div>
</body>
</html>

<?php
$conn->close();
?>
