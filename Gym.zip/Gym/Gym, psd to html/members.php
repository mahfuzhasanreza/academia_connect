<?php
$servername = "localhost"; 
$username = "root";
$password = ""; 
$dbname = "academia_connect"; 

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle delete action
$deleteMessage = "";
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $sql = "DELETE FROM members WHERE id='$id'";
    if ($conn->query($sql) === TRUE) {
        // $deleteMessage = "Record deleted successfully!";
    } else {
        $deleteMessage = "Error deleting record: " . $conn->error;
    }
}

// Fetch members
$sql = "SELECT * FROM members";
$result = $conn->query($sql);

// Function to calculate time ago
function time_ago($datetime) {
    $now = new DateTime();
    $join_date = new DateTime($datetime);
    $interval = $now->diff($join_date);

    if ($interval->y > 0) {
        return $interval->y . ' year' . ($interval->y > 1 ? 's' : '') . ' ago';
    } elseif ($interval->m > 0) {
        return $interval->m . ' month' . ($interval->m > 1 ? 's' : '') . ' ago';
    } elseif ($interval->d > 0) {
        return $interval->d . ' day' . ($interval->d > 1 ? 's' : '') . ' ago';
    } elseif ($interval->h > 0) {
        return $interval->h . ' hour' . ($interval->h > 1 ? 's' : '') . ' ago';
    } elseif ($interval->i > 0) {
        return $interval->i . ' minute' . ($interval->i > 1 ? 's' : '') . ' ago';
    } else {
        return 'just now';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Members</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <style>
        body {
            background: linear-gradient(45deg, #FFA500, #FF4500);
            color: #fff;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            overflow: hidden;
        }
        .container {
            position: relative;
            background: linear-gradient(45deg, #808080, #A9A9A9);
            color: #000;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.4);
            width: 70%;
            height: 80%;
            overflow: hidden;
        }
        .btn-primary, .btn-danger {
            width: 100%;
            background: linear-gradient(45deg, #333, #555);
            border: none;
            margin-bottom: 10px;
        }
        .btn-primary:hover, .btn-danger:hover {
            background: linear-gradient(45deg, #555, #777);
        }
        .form-control {
            width: 100%;
        }
        .close-btn {
            position: absolute;
            top: 10px;
            right: 10px;
            font-size: 24px;
            color: #fff;
            text-decoration: none;
        }
        .table-responsive {
            max-height: calc(100% - 70px); /* Adjust based on header height */
            overflow-y: auto;
        }
        .table thead th {
            position: sticky;
            top: 0;
            background: #333; /* Different color for table headers */
            color: #fff;
        }
        .alert {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            z-index: 1000;
            width: 300px;
            display: none;
            background-color: #28a745; /* Different color */
            color: #fff;
            text-align: center;
            padding: 10px;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="index.php" class="close-btn">&times;</a>
        <h1 class="mt-5">Members List</h1>
        <?php if ($deleteMessage): ?>
        <div class="alert" id="alert"><?php echo $deleteMessage; ?></div>
        <?php endif; ?>
        <div class="table-responsive">
            <table class="table table-bordered mt-3">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Phone Number</th>
                        <th>Plan Type</th>
                        <th>Join Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            $timeAgo = time_ago($row['join_date']);
                            echo '<tr>
                                <td>' . $row['id'] . '</td>
                                <td>' . $row['first_name'] . '</td>
                                <td>' . $row['last_name'] . '</td>
                                <td>' . $row['phone_no'] . '</td>
                                <td>' . $row['plan_type'] . '</td>
                                <td>' . $row['join_date'] . '<br><small>' . $timeAgo . '</small></td>
                                <td>
                                    <a href="edit_member.php?id=' . $row['id'] . '" class="btn btn-primary">Update</a>
                                    <a href="?delete=' . $row['id'] . '" class="btn btn-danger" onclick="return confirm(\'Are you sure?\')">Delete</a>
                                </td>
                            </tr>';
                        }
                    } else {
                        echo '<tr><td colspan="7">No members found</td></tr>';
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var alert = document.getElementById('alert');
            if (alert && alert.textContent.trim() !== "") {
                alert.style.display = 'block';
                setTimeout(function() {
                    alert.style.display = 'none';
                }, 1500);
            }
        });
    </script>
</body>
</html>

<?php
$conn->close();
?>
