<?php
$servername = "localhost"; 
$username = "root";
$password = ""; 
$dbname = "academia_connect"; 

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $conn->real_escape_string($_POST['name']);
    $description = $conn->real_escape_string($_POST['description']);
    $designation = $conn->real_escape_string($_POST['designation']);
    
    // Check if a file was uploaded
    $photo_data = '';
    if ($_FILES["photo"]["name"]) {
        $photo_data = addslashes(file_get_contents($_FILES["photo"]["tmp_name"]));
    }

    // Insert trainer details
    $sql_insert_trainer = "INSERT INTO trainers (name, description, designation, photo_url) VALUES ('$name', '$description', '$designation', '$photo_data')";
    if ($conn->query($sql_insert_trainer) === TRUE) {
        $trainer_id = $conn->insert_id;

        // Insert trainer social link
        $facebook_link = $conn->real_escape_string($_POST['facebook_link']);
        $x_link = $conn->real_escape_string($_POST['x_link']);
        $linkedin_link = $conn->real_escape_string($_POST['linkedin_link']);
        $sql_insert_social_links = "INSERT INTO trainer_social_link (trainer_id, facebook_link, x_link, linkedin_link) VALUES ('$trainer_id', '$facebook_link', '$x_link', '$linkedin_link')";
        $conn->query($sql_insert_social_links);

        echo "Trainer added successfully!";
        header("Location: view_trainers.php");
        exit();
    } else {
        echo "Error adding trainer: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Trainer</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <style>
        body {
            background: linear-gradient(45deg, #FFA500, #FF4500);
            color: #fff;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background: linear-gradient(45deg, #808080, #A9A9A9);
            color: #000;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.4);
        }
        .btn-primary {
            width: 100%;
            background: linear-gradient(45deg, #333, #555);
            border: none;
            margin-top: 10px;
        }
        .btn-primary:hover {
            background: linear-gradient(45deg, #555, #777);
        }
        .form-control {
            width: 100%;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="mt-5">Add Trainer</h1>
        <form method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" name="name" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="description">Description</label>
                <textarea name="description" class="form-control" required></textarea>
            </div>
            <div class="form-group">
                <label for="designation">Designation</label>
                <input type="text" name="designation" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="photo">Photo</label>
                <input type="file" name="photo" class="form-control-file">
            </div>
            <!-- Social Links Section -->
            <div class="form-group">
                <label for="facebook_link">Facebook Link</label>
                <input type="text" name="facebook_link" class="form-control">
            </div>
            <div class="form-group">
                <label for="x_link">X Link</label>
                <input type="text" name="x_link" class="form-control">
            </div>
            <div class="form-group">
                <label for="linkedin_link">LinkedIn Link</label>
                <input type="text" name="linkedin_link" class="form-control">
            </div>
            <button type="submit" class="btn btn-primary">Add Trainer</button>
        </form>
    </div>
</body>
</html>
